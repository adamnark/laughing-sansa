/*
 */
package swing.components.game.play.playarea;

/**
 *
 * @author adamnark
 */
public interface IPlayAreaPanel {

    public void refresh();

    public void disableThrowing();

    public void disableRequsting();
    
    public void enableThrowing();

    public void enableRequsting();
    
    
}
