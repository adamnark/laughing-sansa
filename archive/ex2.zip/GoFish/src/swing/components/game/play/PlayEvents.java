/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swing.components.game.play;

/**
 *
 * @author Natalie
 */
public class PlayEvents {

    public static final String EVENT_SKIP = "EVENT_SKIP";
    public static final String EVENT_REQUEST = "EVENT_REQUST";
    public static final String EVENT_THROW = "EVENT_THROW";
    public static final String EVENT_PLAY_COMPUTER_TURN = "EVENT_PLAY_COMPUTER_TURN";
}
