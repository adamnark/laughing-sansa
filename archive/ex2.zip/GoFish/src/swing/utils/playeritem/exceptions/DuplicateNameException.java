package swing.utils.playeritem.exceptions;

/**
 *
 * @author adamnark
 */
public class DuplicateNameException extends RuntimeException {

    public DuplicateNameException() {
    }

}
