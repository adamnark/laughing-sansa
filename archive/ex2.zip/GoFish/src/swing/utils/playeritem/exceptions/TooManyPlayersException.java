package swing.utils.playeritem.exceptions;

/**
 *
 * @author adamnark
 */
public class TooManyPlayersException extends RuntimeException {

    public TooManyPlayersException() {
    }

}
