package engine.players.exceptions;

/**
 *
 * @author adamnark
 */
public class InvalidFourRuntimeException extends RuntimeException {

    public InvalidFourRuntimeException() {
    }

}
