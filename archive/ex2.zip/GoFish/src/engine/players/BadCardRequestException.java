package engine.players;

/**
 *
 * @author adamnark
 */
public class BadCardRequestException extends Exception {

}
