ADAM NARKUNSKI 300232113

				     GO FISH EXERCISE 2 - SWING
					       NOTES

	The NetBeans project is the included directory, GoFish.
	Dependencies: Google's guava library, guava-14.0.1.jar. It is included in the zip file. 
	The class that you should start is swing.Main (class Main in package swing).

	Assumptions:
	1. Each card should have the same number of serieses as all the other cards. For example, 
	if one card is a member of two serieses, then we assume all other cards are
	members of two serieses.
	2. When the user opts for a manual game, he can choose settings, choose player types
	and names, but cards are automatically generated. I didn't think it's
	reasonable to specify 28+ cards (each with different names etc) every time you want
	to start a new game.

	Usage notes:
	To start a game with "manual" settings, click "Start a new game".
	To start a game with settings from an XML file, click "Load game from XML".

	After starting a game, when you go back to the main menu, the "Replay with last settings" 
	button should be enabled and you can play again with the same settings. 



	Thanks.
	Adam
